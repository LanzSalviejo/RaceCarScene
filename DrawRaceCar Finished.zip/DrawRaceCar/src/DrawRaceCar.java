// Program DrawRaceCar
// Purpose:
//		The purpose of this application is to 
//		draw a race car scene as specified 
//		in the assignment, using various shapes
//		such as rectangles, circles, and polygons.
// Programmer: Warren Edwards
// Date: March 2024
//

// Import the necessary Javafx components
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class DrawRaceCar extends Application {
	
	// Named constants
	static final double DEFAULT_SCENE_WIDTH = 1400;
	static final double DEFAULT_SCENE_HEIGHT = 400;
	
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) { 
		
		// Create a RaceCarScene
		RaceCarScene raceCarScene = new RaceCarScene();
		
		// Create a scene and place it in the stage
		Scene scene = new Scene(raceCarScene, DEFAULT_SCENE_WIDTH, DEFAULT_SCENE_HEIGHT);
		primaryStage.setTitle("Race Car Scene");
		primaryStage.setScene(scene);
		primaryStage.show();
		
		Timeline start = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            raceCarScene.moveRight();
            // Toggle flameColor between ORANGE and YELLOW
            if (raceCarScene.flameColor == Color.DARKORANGE) {
                raceCarScene.flameColor = Color.GOLD;
            } else {
                raceCarScene.flameColor = Color.DARKORANGE;
            }//if
            
            // Change headLight color to YELLOW
            raceCarScene.headLight1 = (Color.rgb(255, 255, 0, 0.7));
        }));
        start.setCycleCount(Timeline.INDEFINITE);
        start.pause();
        
        // Add mouse event handler to play/pause animation when clicked
        scene.setOnMousePressed(event -> {
            start.play();
        });

        scene.setOnMouseReleased(event -> {
            start.pause();
        });
		
		// Print out the author
		System.out.println("Modified by Lanz Salviejo, Spring 2024");
    
	}//start

	// The main method is only needed for the IDE with limited
	//JavaFX support. Not needed for running from the command line.	*/
	public static void main(String[] args) {
		launch(args);
	}//main

}// DrawRaceCar