// RaceCarScene Class
//		RaceCarScene class is a subclass of Pane 
//		class.   Purpose is to draw a race car scene 
//		using circles, rectangles and polygons in the 
//		paintRaceCarScene method defined below.   
//		Comments are included to give you guidance as to what to do.

// Import the necessary Javafx components
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class RaceCarScene extends Pane {
		
	// Constants to define various object dimensions
	// You may have to define more if your car and
	// scene design is more complex
	private final double CAR_BODY_WIDTH = 175;
	private final double CAR_BODY_HEIGHT = 50;
	private final double BACK_WHEEL_RADIUS = 30;
	private final double FRONT_WHEEL_RADIUS = 30;
	private final double GROUND_HEIGHT = 100;
	private final double MOON_RADIUS = 30;
	
	// Constants to define various offsets from
	// a base location defined by baseY and baseX
	private final double CAR_XOFFSET = 100;
	private final double CAR_BODY_GROUND_CLEARANCE = 10;
	private final double BACK_WHEEL_XOFFSET = CAR_BODY_WIDTH*0.25;
	private final double FRONT_WHEEL_XOFFSET = CAR_BODY_WIDTH*0.9;
	
	// Constant to define various offsets for various
	// objects relative to the scene dimensions.
	private double MOON_XOFFSET = 150;
	private final double MOON_YOFFSET = 25;
	
	// Private data fields baseX and baseY to keep 
	// track of where the base of the car should be
	// relative to the overall scene.   The car will 
	// initially be on the left side of the pane
	// on the "ground" at the bottom of the pane
	private double baseX = CAR_XOFFSET;		
	private double baseY = DrawRaceCar.DEFAULT_SCENE_HEIGHT - GROUND_HEIGHT;
	
	// Constants for bumper Parts
	private final double BUMPER_X = 200;
	private final double BUMPER_Y = 30;
	private final double BUMPER_WIDTH = 20;
	private final double BUMPER_HEIGHT = 20;
	private final double REAR_BUMPER_Y = 35;
	private final double REAR_BUMPER_WIDTH = 20;
	private final double REAR_BUMPER_HEIGHT = 10;
	
	// Constants for Tail and Headlights
	private final double TAIL_LIGHT_Y = 25;
	private final double HEAD_LIGHT_X = 200;
	private final double HEAD_LIGHT_Y = 17;
	private final double LIGHT_RADIUS_X = 5;
	private final double LIGHT_RADIUS_Y = 10;
	private final double SIDE_LIGHT_X = 191;
	private final double SIDE_LIGHT_Y =  35;
	private final double SIDE_LIGHT_WIDTH = 6;
	private final double SIDE_LIGHT_HEIGHT = 10;
	
	// Constants for Handle
	private final double HANDLE_X = 80;
	private final double HANDLE_WIDTH = 10;
	private final double HANDLE_HEIGHT = 5;
	
	// Constants for lights
	private final double LIGHT_X1 = 400;
	private final double LIGHT_Y1 = 100;
	private final double LIGHT_X2 = 400;
	private final double LIGHT_X3 = 150;
	private final double LIGHT_Y3 = 40;
	
	// Random number generator for flame
	private double randomNumber;
	
	// Data field for rotation of wheels
	private double rotateAngle;
	
	// Road line X offsets
	private double roadLineX = 75;
	private double roadLine2X = 225;
	private double roadLine3X = 375;
	private double roadLine4X = 525;
	private double roadLine5X = 675;
	private double roadLine6X = 825;
	private double roadLine7X = 975;
	private double roadLine8X = 1125;
	private double roadLine9X = 1275;
	private double roadLine10X = 1425;
	private double roadLine11X = 1575;
	
	// Data fields for building
    private double buildingOffset1 = 500;
    private double buildingOffset2 = 300;
    private double buildingOffset3 = 800;
    private double buildingOffset4 = 1100;
    private double building1X = 100;
    private double building2X = 150;
    private double building3X = 150;
    private double building4X = 200;
    private double building1Y = 300;
    private double building2Y = 400;
    private double building3Y = 250;
    private double building4Y = 200;
	
	// Transperant color for windows, light, and flame
	Color window = Color.DARKCYAN;
	Color transperantWindow = window.deriveColor(0, 1, 1, 0.7); // Makes window transperant
	Color headLight1;
	public Color flameColor;
	
	// Non-arg constructor for RaceCarScene
	// Simply paint the race car scene
	public RaceCarScene() {						
		paintRaceCarScene();
	}// RaceCarScene
    
	// Method paintRaceCarScene
	//	Paint the race car scene in the correct location
	// 	using Circles, Rectangles and Polygons 
	private void paintRaceCarScene () {

		// Create ground using a Rectangle class
		Rectangle ground = new Rectangle(
				0, baseY, getWidth(), GROUND_HEIGHT);
		ground.setFill(Color.GREY);	
		
		// Print the author's name on the ground
		// with the word "Raceway" using a Text class
		Text author = new Text("Lanz's Highway");
		author.setFont(Font.font("Courier", FontWeight.NORMAL, 
			    FontPosture.REGULAR, getWidth() / 30));
		author.xProperty().bind(widthProperty().divide(3));
		author.yProperty().bind(heightProperty().subtract(GROUND_HEIGHT/2));

	    // Create the body of the race car using
	    // various shapes - be creative here as you
	    // can use numerous different shapes to define
	    // the race car you have designed
		Rectangle raceCarBody = new Rectangle(
				baseX + 25, 
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT, 
				CAR_BODY_WIDTH, 
				CAR_BODY_HEIGHT);
		raceCarBody.setFill(Color.SILVER);	
		
		Rectangle handle = new Rectangle(
				baseX + HANDLE_X, 
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT, 
				HANDLE_WIDTH, 
				HANDLE_HEIGHT);
		handle.setFill(Color.DARKGRAY);
		handle.setStroke(Color.BLACK);
		
		
		Rectangle bumper = new Rectangle(
				baseX + BUMPER_X, 
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + BUMPER_Y, 
				BUMPER_WIDTH, 
				BUMPER_HEIGHT);
		bumper.setFill(Color.DARKGRAY);
		bumper.setStroke(Color.BLACK);
		
		Rectangle rearBumper = new Rectangle(
				baseX, 
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + REAR_BUMPER_Y, 
				REAR_BUMPER_WIDTH, 
				REAR_BUMPER_HEIGHT);
		rearBumper.setFill(Color.DARKGRAY);
		rearBumper.setStroke(Color.BLACK);
		
		Polygon flame = new Polygon(
				baseX,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + REAR_BUMPER_Y + 5,
				baseX - randomNumber,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + REAR_BUMPER_Y + 10,
				baseX,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + REAR_BUMPER_Y + 15
				);
		flame.setFill(flameColor);
		
		Polygon rearPolygon = new Polygon(
				baseX,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + 10,
				baseX + 25,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT,
				baseX + 30,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + 45,
				baseX,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + 45
				);
		rearPolygon.setFill(Color.SILVER);
		
		
		// Lights of the race car
		Ellipse tailLight = new Ellipse(
				baseX,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + TAIL_LIGHT_Y,
				LIGHT_RADIUS_X,
				LIGHT_RADIUS_Y);
		tailLight.setFill(Color.RED);
		tailLight.setStroke(Color.BLACK);
		
		Ellipse headLight = new Ellipse(
				baseX + HEAD_LIGHT_X,
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + HEAD_LIGHT_Y,
				LIGHT_RADIUS_X,
				LIGHT_RADIUS_Y);
		headLight.setFill(Color.WHITE);
		headLight.setStroke(Color.BLACK);
		
		Rectangle sideLight = new Rectangle(
				baseX + SIDE_LIGHT_X, 
				baseY - CAR_BODY_GROUND_CLEARANCE - CAR_BODY_HEIGHT + SIDE_LIGHT_Y, 
				SIDE_LIGHT_WIDTH, 
				SIDE_LIGHT_HEIGHT);
		sideLight.setFill(Color.ORANGE);
		sideLight.setStroke(Color.BLACK);
		
		Polygon light = new Polygon(
				baseX + LIGHT_X1,
				baseY - LIGHT_Y1,
				baseX + LIGHT_X2,
				baseY,
				baseX + LIGHT_X3,
				baseY - LIGHT_Y3);
		light.setFill(headLight1);
		
		// Shapes for roof of the car
		Rectangle roof = new Rectangle(
				baseX + 80,
				baseY - 100,
				55,
				40);
		roof.setFill(Color.SILVER);
		
		Polygon roofPolygon = new Polygon(
				baseX + 80,
				baseY - 50,
				baseX + 80.5,
				baseY - 100.5,
				baseX + 30,
				baseY - 60
				);
		roofPolygon.setFill(Color.SILVER);
		
		Polygon frontRoofPolygon = new Polygon(
				baseX + 170,
				baseY - 60,
				baseX + 134,
				baseY - 100.5,
				baseX + 134,
				baseY - 50
				);
		frontRoofPolygon.setFill(Color.SILVER);
		
		Polygon windowPolygon = new Polygon(
				baseX + 78,
				baseY - 63,
				baseX + 78,
				baseY - 95,
				baseX + 40,
				baseY - 63
				);
		windowPolygon.setFill(transperantWindow);
		
		Polygon frontWindowPolygon = new Polygon(
				baseX + 163,
				baseY - 63,
				baseX + 134,
				baseY - 96,
				baseX + 134,
				baseY - 63
				);
		frontWindowPolygon.setFill(transperantWindow);
		
		Rectangle window = new Rectangle(
				baseX + 81,
				baseY - 97,
				50,
				34);
		window.setFill(transperantWindow);
		
		Circle person = new Circle(
				baseX + 110,
				baseY - 80,
				15);
		person.setFill(Color.WHITE);	
		
	    // Create the wheels of the race car using
	    // circles (for the wheels) and lines (for the
		// spokes of the wheel
		Circle backWheel = new Circle(
				baseX + BACK_WHEEL_XOFFSET,
				baseY - CAR_BODY_GROUND_CLEARANCE,
				BACK_WHEEL_RADIUS);
		backWheel.setFill(Color.BLACK);	
		
		Circle backWheelInner = new Circle(
				baseX + BACK_WHEEL_XOFFSET,
				baseY - CAR_BODY_GROUND_CLEARANCE,
				17);
		backWheelInner.setFill(Color.DARKGRAY);	
		
		Circle backWheelInner2 = new Circle(
				baseX + BACK_WHEEL_XOFFSET,
				baseY - CAR_BODY_GROUND_CLEARANCE,
				15);
		backWheelInner2.setFill(Color.BLACK);	
		
		Circle backWheelInner3 = new Circle(
				baseX + BACK_WHEEL_XOFFSET,
				baseY - CAR_BODY_GROUND_CLEARANCE,
				13);
		backWheelInner3.setFill(Color.DARKGRAY);	
		
		// Lines for the backwheel spokes
		Line line1 = new Line(baseX + BACK_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + BACK_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line1.setRotate(rotateAngle);
	    line1.setStrokeWidth(2);
	    line1.setStroke(Color.BLACK);
	    
		Line line2 = new Line(baseX + BACK_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + BACK_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line2.setRotate(rotateAngle + 30);
	    line2.setStrokeWidth(2);
	    line2.setStroke(Color.BLACK);
	    
		Line line3 = new Line(baseX + BACK_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + BACK_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line3.setRotate(rotateAngle + 60);
	    line3.setStrokeWidth(2);
	    line3.setStroke(Color.BLACK);
	    
		Line line4 = new Line(baseX + BACK_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + BACK_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line4.setRotate(rotateAngle + 90);
	    line4.setStrokeWidth(2);
	    line4.setStroke(Color.BLACK);
	    
		Line line5 = new Line(baseX + BACK_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + BACK_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line5.setRotate(rotateAngle + 120);
	    line5.setStrokeWidth(2);
	    line5.setStroke(Color.BLACK);
	    
		Line line6 = new Line(baseX + BACK_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + BACK_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line6.setRotate(rotateAngle + 150);
	    line6.setStrokeWidth(2);
	    line6.setStroke(Color.BLACK);
	    
		Line line7 = new Line(baseX + BACK_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + BACK_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line7.setRotate(rotateAngle + 180);
	    line7.setStrokeWidth(2);
	    line7.setStroke(Color.BLACK);

	    // Start of frontwheel objects
		Circle frontWheel = new Circle(
				baseX + FRONT_WHEEL_XOFFSET,
				baseY - CAR_BODY_GROUND_CLEARANCE,
				FRONT_WHEEL_RADIUS);
		frontWheel.setFill(Color.BLACK);
		
		Circle frontWheelInner = new Circle(
				baseX + FRONT_WHEEL_XOFFSET,
				baseY - CAR_BODY_GROUND_CLEARANCE,
				17);
		frontWheelInner.setFill(Color.DARKGRAY);

		Circle frontWheelInner2 = new Circle(
				baseX + FRONT_WHEEL_XOFFSET,
				baseY - CAR_BODY_GROUND_CLEARANCE,
				15);
		frontWheelInner2.setFill(Color.BLACK);	
		
		Circle frontWheelInner3 = new Circle(
				baseX + FRONT_WHEEL_XOFFSET,
				baseY - CAR_BODY_GROUND_CLEARANCE,
				13);
		frontWheelInner3.setFill(Color.DARKGRAY);	
		
		Line line8 = new Line(baseX + FRONT_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + FRONT_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line8.setRotate(rotateAngle);
	    line8.setStrokeWidth(2);
	    line8.setStroke(Color.BLACK);
	    
	    // Lines for frontwheel spokes
		Line line9 = new Line(baseX + FRONT_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + FRONT_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line9.setRotate(rotateAngle + 30);
	    line9.setStrokeWidth(2);
	    line9.setStroke(Color.BLACK);
	    
		Line line10 = new Line(baseX + FRONT_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + FRONT_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line10.setRotate(rotateAngle + 60);
	    line10.setStrokeWidth(2);
	    line10.setStroke(Color.BLACK);
	    
		Line line11 = new Line(baseX + FRONT_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + FRONT_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line11.setRotate(rotateAngle + 90);
	    line11.setStrokeWidth(2);
	    line11.setStroke(Color.BLACK);
	    
		Line line12 = new Line(baseX + FRONT_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + FRONT_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line12.setRotate(rotateAngle + 120);
	    line12.setStrokeWidth(2);
	    line12.setStroke(Color.BLACK);
	    
		Line line13 = new Line(baseX + FRONT_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + FRONT_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line13.setRotate(rotateAngle + 150);
	    line13.setStrokeWidth(2);
	    line13.setStroke(Color.BLACK);
	    
		Line line14 = new Line(baseX + FRONT_WHEEL_XOFFSET - 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE - 8, 
				baseX + FRONT_WHEEL_XOFFSET + 8, 
				baseY - CAR_BODY_GROUND_CLEARANCE + 8);
		line14.setRotate(rotateAngle + 180);
	    line14.setStrokeWidth(2);
	    line14.setStroke(Color.BLACK);
		
		
		// Draw the moon using a circle
		Circle moon = new Circle(
				getWidth() - MOON_XOFFSET + MOON_RADIUS/2.0, // Calculate center X
				MOON_YOFFSET + MOON_RADIUS, // Calculate center Y
				MOON_RADIUS);
		moon.setFill(Color.YELLOW);
		moon.setStroke(Color.BLACK);
		
		// Objects for road lines
		Rectangle roadLine = new Rectangle(
				roadLineX,
				baseY,
				75,
				10);
		roadLine.setFill(Color.GOLD);
		
		Rectangle roadLine2 = new Rectangle(
				roadLine2X,
				baseY,
				75,
				10);
		roadLine2.setFill(Color.GOLD);
		
		Rectangle roadLine3 = new Rectangle(
				roadLine3X,
				baseY,
				75,
				10);
		roadLine3.setFill(Color.GOLD);
		
		Rectangle roadLine4 = new Rectangle(
				roadLine4X,
				baseY,
				75,
				10);
		roadLine4.setFill(Color.GOLD);
		
		Rectangle roadLine5 = new Rectangle(
				roadLine5X,
				baseY,
				75,
				10);
		roadLine5.setFill(Color.GOLD);
		
		Rectangle roadLine6 = new Rectangle(
				roadLine6X,
				baseY,
				75,
				10);
		roadLine6.setFill(Color.GOLD);
		
		Rectangle roadLine7 = new Rectangle(
				roadLine7X,
				baseY,
				75,
				10);
		roadLine7.setFill(Color.GOLD);
		
		Rectangle roadLine8 = new Rectangle(
				roadLine8X,
				baseY,
				75,
				10);
		roadLine8.setFill(Color.GOLD);
		
		Rectangle roadLine9 = new Rectangle(
				roadLine9X,
				baseY,
				75,
				10);
		roadLine9.setFill(Color.GOLD);
		
		Rectangle roadLine10 = new Rectangle(
				roadLine10X,
				baseY,
				75,
				10);
		roadLine10.setFill(Color.GOLD);
		
		Rectangle roadLine11 = new Rectangle(
				roadLine11X,
				baseY,
				75,
				10);
		roadLine11.setFill(Color.GOLD);
		
		// Building Objects
		Rectangle building1 = new Rectangle(
                buildingOffset1, 
                baseY - 200, 
                building1X, 
                building1Y);
        building1.setFill(Color.DARKGRAY);
        building1.setStroke(Color.BLACK);

        Rectangle building2 = new Rectangle(
                buildingOffset2, 
                baseY - 300, 
                building2X, 
                building2Y);
        building2.setFill(Color.DARKGRAY);
        building2.setStroke(Color.BLACK);
        
        Rectangle building3 = new Rectangle(
                buildingOffset3, 
                baseY - 250, 
                building3X, 
                building3Y);
        building3.setFill(Color.DARKGRAY);
        building3.setStroke(Color.BLACK);
        
        Rectangle building4 = new Rectangle(
                buildingOffset4, 
                baseY - 200, 
                building4X, 
                building4Y);
        building4.setFill(Color.DARKGRAY);
        building4.setStroke(Color.BLACK);
		
		
		// Clear the RaceCarScene (remove all
		// the children), set the style background
		// to desired colour and then and add the 
		// scene components (e.g. ground, author, carBody,
		// backWheel, frontWheel, moon, etc...)
		this.getChildren().clear();
		this.setStyle("-fx-background-color: BLACK;");
		this.getChildren().addAll(moon, building1, building2, building3, building4,
				light, ground, author, raceCarBody, handle, rearPolygon, flame, rearBumper, bumper, tailLight, headLight, sideLight,
				roof, roofPolygon, frontRoofPolygon, windowPolygon, person, window, frontWindowPolygon,
				roadLine, roadLine2, roadLine3, roadLine4, roadLine5, roadLine6, roadLine7, roadLine8, roadLine9, roadLine10, roadLine11,
				backWheel, backWheelInner, backWheelInner2, backWheelInner3, line1, line2, line3, line4, line5, line6, line7,
				frontWheel, frontWheelInner, frontWheelInner2, frontWheelInner3, line8, line9, line10, line11, line12, line13, line14
				);
        
	}// paintRaceCarScene
		
	// setWidth 
	//	This method is called when window is resized.
	// 	If the width is changed, you may need to recalculate 
	//  the baseX location so the scene will redraw properly
	@Override
	public void setWidth(double width) {
		super.setWidth(width);
		baseX = CAR_XOFFSET;
		paintRaceCarScene();
	}//setWidth
	  
	// setHeight 
	//	This method is called when window is resized.
	// 	If the height is changed, you may need to recalculate 
	//	the baseY location so the scene will redraw properly
	@Override
	public void setHeight(double height) {
		super.setHeight(height);
		baseY = height - GROUND_HEIGHT;
		paintRaceCarScene();
	}//setWidth

    public void moveRight() {
    	if (baseX < getWidth() - 500) {
    		baseX += 5;
    		//line1.setRotate(15);
    	}//if
    	
        // Move objects to the left when the car moves right
        if (baseX == getWidth() - 500) {
            MOON_XOFFSET += 1;
            buildingOffset1 -= 2;
            buildingOffset2 -= 2;
            buildingOffset3 -= 2;
            buildingOffset4 -= 2;
            roadLineX -= 7;
            roadLine2X -= 7;
            roadLine3X -= 7;
            roadLine4X -= 7;
            roadLine5X -= 7;
            roadLine6X -= 7;
            roadLine7X -= 7;
            roadLine8X -= 7;
            roadLine9X -= 7;
            roadLine10X -= 7;
            roadLine11X -= 7;
        }//if
        
        // Check if the moon has reached the left boundary
        if (MOON_XOFFSET > getWidth() + 200) {
            // Reset the moon's X offset to a position on the right side of the screen
            MOON_XOFFSET = -300;
        }//if
        
        // Reset the roadLine's position to the right side of the screen once it reaches the end of the left side boundary
        if (roadLineX < -75) {
            roadLineX = getWidth() + 150;
        }//if
        if (roadLine2X < -75) {
            roadLine2X = getWidth() + 150;
        }//if
        if (roadLine3X < -75) {
            roadLine3X = getWidth() + 150;
        }//if
        if (roadLine4X < -75) {
            roadLine4X = getWidth() + 150;
        }//if
        if (roadLine5X < -75) {
            roadLine5X = getWidth() + 150;
        }//if
        if (roadLine6X < -75) {
            roadLine6X = getWidth() + 150;
        }//if
        if (roadLine7X < -75) {
            roadLine7X = getWidth() + 150;
        }//if
        if (roadLine8X < -75) {
            roadLine8X = getWidth() + 150;
        }//if
        if (roadLine9X < -75) {
            roadLine9X = getWidth() + 150;
        }//if
        if (roadLine10X < -75) {
            roadLine10X = getWidth() + 150;
        }//if
        if (roadLine11X < -75) {
            roadLine11X = getWidth() + 150;
        }//if
        
        // Check if the buildingOffset has reached the left boundary
        if (buildingOffset1 < -300) {
            // Reset the buildingOffset to a position on the right side of the screen
            buildingOffset1 = getWidth() + (Math.random() * 500) + 1;
            building1X = (Math.random() * 200) + 100;
        }//if

        if (buildingOffset2 < -300) {
            buildingOffset2 = getWidth() + (Math.random() * 500) + 1;
            building2X = (Math.random() * 200) + 100;
        }//if
        
        if (buildingOffset3 < -300) {
            buildingOffset3 = getWidth() + (Math.random() * 500) + 1;
            building3X = (Math.random() * 200) + 100;
        }//if
        
        if (buildingOffset4 < -300) {
            buildingOffset4 = getWidth() + (Math.random() * 500) + 1;
            building4X = (Math.random() * 200) + 100;
        }//if

    	// Rotate spokes by 5
    	rotateAngle +=5;
   
    	// Generates random number between 5 and 20 for flames
    	randomNumber = (Math.random() * 16) + 5;
    	
        paintRaceCarScene(); // Redraw the scene with the updated position
    }//moveRight
}// RaceCarScene